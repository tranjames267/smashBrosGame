// CSCI 1300 Fall 2020
// Author: James Tran
// Recitation: 224 - Anuj Pasricha 
// Project 3

#include <string>
#include <fstream>
#include <iostream>
#include "Game.h"
#include "Character.h"
#include "Moves.h"
#include "ItemEvent.h"

using namespace std;

Game::Game()
{
    Character characters[4];
    Moves allMoves[24]; 
    ItemEvent events[5]; 
    Character player;
    Character computer; 
    bool gameWon = false;  
} 
int Game::split(string splitStr, char separator, string arr[], int size)
{
    // check for the number of separators
    int numSeparator = 0;
    for(int i=0; i<splitStr.length(); i++)
    {
        if(splitStr[i] == separator)
        {
            numSeparator ++; 
        }
    }
    if(splitStr.length() == 0) // no smaller strings possible if splitStr is empty
    {
        return 0; 
    }
    else if(numSeparator == 0) // assign first element in the array to splitStr if no delimiter is found. Always 1 string
    {
        arr[0] = splitStr; 
        return 1;
    }
    else if(numSeparator >= size) // if there are more smaller strings than space in the array, fill up array but return -1
    {
        int arrayPos = 0; // accounts for the index in the array
        string strToArray = ""; 
     
        for(int i=0; i<splitStr.length(); i++)
        {
            if(splitStr[i] != separator)
            {
                strToArray += splitStr[i]; // add the character to the smaller string
            }
            if(splitStr[i] == separator)
            {
                arr[arrayPos] = strToArray; // add the smaller string to the array
                strToArray = ""; // reset the smaller string
                arrayPos ++; 
                
                if(arrayPos == size) // stop if the array is all filled
                break;
            }
        }
        return -1;
    }
    
    else // fill up an array that can fit all smaller strings and return the number of smaller strings
    { 
        int numItems = 1; // 1 accounts for the last smaller string 
        int arrayPos = 0; 
         
        string strToArray = ""; 
     
        for(int i=0; i<splitStr.length(); i++)
        {
            if(splitStr[i] != separator)
            {
                strToArray += splitStr[i]; 
            }
            if(splitStr[i] == separator)
            {
                arr[arrayPos] = strToArray; 
                strToArray = "";
                numItems ++; // keep count of the number of smaller strings
                arrayPos ++; // move to the next index of the array
            }
        }
        arr[arrayPos] = strToArray; // add the last string to the array
        
        return numItems;  
    }
}
void Game::readAsciiArt(string fileName)
{
    string line; // will be the line variable for getline()
    ifstream inFile; // input from a plain txt file 

    inFile.open(fileName);

    // check if the file is opened
    if(inFile.fail())
    {
        cout << "Could not open file." <<endl;
    } 
    else
    {
        while(getline(inFile, line))
        {
            if(line.length() > 0) // ensures that we don't process empty lines
            {
                cout << line <<endl;  
            }
        }
    }
} 
bool Game::readCharacters(string fileName, Character allCharacters[])
{
    // this will fill up the array of all characters by reading in characters.txt
    // I will use a storage array of type string to contain all the information (will most likely need .stoi())
    // most likely will call on split()
} 
bool Game::readMoves(string fileName, Moves everyMove[])
{
    // this will fill up the array of all the moves by reading in moves.txt
    // a storage array of type string will contain the information (will most likely need .stoi())
    // will also call on split()
}
bool Game::readEvents(string fileName, ItemEvent allEvents[])
{
    // this will fill up the array of all the item events by reading in items.txt
    // a storage array of type string will contain the information (will most likely need .stoi())
    // will also call on split()
}
void Game::sortByPower(Moves moveSet[])
{
    // will implement a bubble sort to sort the moves of a character based on power
    // print out "Moves Sorted: Most Powerful on Top of List"
    // After the moves are sorted, a list of moves will be printed 
}
void Game::sortByProbHit(Moves moveSet[])
{
    // will implement a bubble sort to sort the moves of a character based on probability of hitting
    // print out "Moves Sorted: Most Probable of Hitting on Top of List"
    // After the moves are sorted, a list of moves will be printed 
}
bool Game::attackSuccess(Moves moveChoice)
{
    // generate a random number from 1 to 100
    // if the number is less than or equal to the probHit of the move, return true
    // otherwise, return false
}

void Game::introductionAndDirections()
{
    // read out smashBrosArt.txt 
    // print out directions on how to play the game 
}
void Game::chooseCharacter()
{
    // display a menu with the four character options 
    // depending on the user's choice, read out the character ascii art txt file
    // modify the character object named player to have the attributes of the certain character 
    // assign the name, damage, lives, number of moves made, and moves indexes based on the master array characters[] 
} 
void Game::chooseOpponent()
{
    // display a menu with the four character options 
    // depending on the user's choice, read out the character ascii art txt file
    // modify the character object named computer to have the attributes of the certain character 
    // assign the name, damage, lives, number of moves made, and moves indexes based on the master array characters[]
} 
void Game::battle()
{
    // this is where the main menu of actions will occur 
    // Sort and View Moves of player
        // sort by power and sort by probability
        // computer character won't make a move after this choice 
    // Attack
        // will be given a list of moves of the character to choose from
        // call on attackSuccess() to see if the move will execute 
        // the attack will change the damage of the computer character
        // the computer character will attack after this choice
    // Heal
        // will lower the player character damage by 20
        // computer character will attack after this choice
    // Grab and use an item
        // generate a random item (probability out of 10)
        // random item will increase damage of computer character
        // computer character will attack after this choice
    // Block
        // player character is guarenteed to inflict damage on computer character by 7
        // computer character will attack, but damage will be divided by 2
    // quit
        // end the program
}
void Game::displayResults()
{
    // display if the player or computer won 
    // read out a character ascii file if the player won by calling readAsciiArt()
    // will write out the user stats to a file if they have won or lost  
} 
bool Game::getGameWon() const
{
    return gameWon;
} 
void Game::setGameWon(bool won)
{
    gameWon = won; 
}