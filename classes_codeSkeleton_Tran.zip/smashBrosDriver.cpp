// CSCI 1300 Fall 2020
// Author: James Tran
// Recitation: 224 - Anuj Pasricha 
// Project 3

#include <string>
#include <fstream>
#include <iostream>
#include "Game.h"
#include "Character.h"
#include "Moves.h"
#include "ItemEvent.h"

using namespace std; 

int main()
{
    Game smashBros; 
    //smashBros.introductionAndDirections();
    //smashBros.chooseCharacter();
    //smashBros.chooseOpponent(); 
    //smashBros.battle();
        // main while loop may occur in here
        // I may change the code later so that the main while loop will happen in the main function
    //smashBros.displayResults();
}